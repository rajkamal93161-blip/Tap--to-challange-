# Tap Challenge Games — Web Version

Open `index.html` in a browser to play.

This version uses virtual demo coins only. It does not process real-money deposits or withdrawals.

For free hosting, upload the folder to a static hosting service such as GitHub Pages or another provider that supports static HTML.
